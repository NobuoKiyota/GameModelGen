from .operators import (
    MESH_OT_reroll_selected_prop,
    MESH_OT_create_new_prop,
    MESH_OT_apply_random_texture_only,
    MESH_OT_bake_prop_textures,
    MESH_OT_export_selected_fbx,
    MESH_OT_open_export_folder,
    MESH_OT_create_grass_field,
    MESH_OT_convert_grass_to_game_mesh,
    MESH_OT_export_animated_water_fbx,
    MESH_OT_setup_water_sky_lighting,
    MESH_OT_generate_image_displace,
    MESH_OT_bake_game_ready_displace,
    MESH_OT_optimize_displace_mesh,
    MESH_OT_import_clipboard_image,
    MESH_OT_import_dropped_image,
    MESH_OT_auto_detect_background_color,
    MESH_OT_generate_flask_potion,
    MESH_OT_regenerate_flask_potion,
    MESH_OT_generate_wall_clock,
    MESH_OT_regenerate_wall_clock,
    MESH_OT_generate_speaker,
    MESH_OT_regenerate_speaker,
    MESH_OT_generate_fence_preset,
    MESH_OT_regenerate_fence_preset,
    MESH_OT_apply_fence_colors
)


from .panel import VIEW3D_PT_prop_studio_panel

classes = (
    MESH_OT_reroll_selected_prop,
    MESH_OT_create_new_prop,
    MESH_OT_apply_random_texture_only,
    MESH_OT_bake_prop_textures,
    MESH_OT_export_selected_fbx,
    MESH_OT_open_export_folder,
    MESH_OT_create_grass_field,
    MESH_OT_convert_grass_to_game_mesh,
    MESH_OT_export_animated_water_fbx,
    MESH_OT_setup_water_sky_lighting,
    MESH_OT_generate_image_displace,
    MESH_OT_bake_game_ready_displace,
    MESH_OT_optimize_displace_mesh,
    MESH_OT_import_clipboard_image,
    MESH_OT_import_dropped_image,
    MESH_OT_auto_detect_background_color,
    MESH_OT_generate_flask_potion,
    MESH_OT_regenerate_flask_potion,
    MESH_OT_generate_wall_clock,
    MESH_OT_regenerate_wall_clock,
    MESH_OT_generate_speaker,
    MESH_OT_regenerate_speaker,
    MESH_OT_generate_fence_preset,
    MESH_OT_regenerate_fence_preset,
    MESH_OT_apply_fence_colors,
    VIEW3D_PT_prop_studio_panel,
)



__all__ = [
    'classes',
    'MESH_OT_reroll_selected_prop',
    'MESH_OT_create_new_prop',
    'MESH_OT_apply_random_texture_only',
    'MESH_OT_bake_prop_textures',
    'MESH_OT_export_selected_fbx',
    'MESH_OT_open_export_folder',
    'MESH_OT_create_grass_field',
    'MESH_OT_convert_grass_to_game_mesh',
    'MESH_OT_export_animated_water_fbx',
    'MESH_OT_setup_water_sky_lighting',
    'VIEW3D_PT_prop_studio_panel'
]
