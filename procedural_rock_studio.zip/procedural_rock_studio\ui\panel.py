import bpy

class VIEW3D_PT_prop_studio_panel(bpy.types.Panel):
    bl_label = "Procedural Prop Studio Pro"
    bl_idname = "VIEW3D_PT_prop_studio_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Prop Studio"

    def draw(self, context):
        layout = self.layout
        props = context.scene.prop_studio_props

        # 🌟 1. Category Selector Box
        box_cat = layout.box()
        box_cat.label(text="Preset Category (プリセット):", icon='ASSET_MANAGER')
        box_cat.prop(props, "prop_category", text="")

        # 🌟 2. Giant Top Action Bar
        box_act = layout.box()
        col_act = box_act.column(align=True)
        col_act.scale_y = 1.35
        row_main = col_act.row(align=True)
        row_main.operator("mesh.update_selected_prop", text="🔄 選択中を反映・更新 (In-Place)", icon='FILE_REFRESH')
        row_main.operator("mesh.reroll_selected_prop", text="🎲 形状を再抽選 (Re-Roll)", icon='DICE')
        
        row_sub_act = col_act.row(align=True)
        row_sub_act.operator("mesh.create_new_prop", text="➕ 新規作成", icon='ADD')
        row_sub_act.operator("mesh.apply_random_texture_only", text="🎨 テクスチャ変更", icon='IMAGE_DATA')

        col_exp = box_act.column(align=True)
        col_exp.scale_y = 1.3
        col_exp.operator("mesh.export_selected_fbx", text="📦 一発 FBX 出力 (Unity用・自動+1連番)", icon='EXPORT')

        # 🔧 モディファイア微調整中の状態表示＆一括確定ボタン
        active_obj = context.active_object
        if active_obj and active_obj.type == 'MESH' and active_obj.modifiers:
            row_mod = box_act.row(align=True)
            row_mod.scale_y = 1.15
            row_mod.operator("mesh.apply_all_modifiers", text=f"🔘 全モディファイアを一括適用 ({len(active_obj.modifiers)}個)", icon='CHECKMARK')

        layout.separator()

        # 🌟 3. Studio Mode Tab Switcher
        row_tabs = layout.row(align=True)
        row_tabs.prop(props, "studio_tab", expand=True)

        layout.separator()

        # 🌟 4. Tab 1: Shape & Dimensions & Specific Controls
        if props.studio_tab == 'SHAPE':
            # Speaker Specific
            if props.prop_category == 'SPEAKER':
                box_spk = layout.box()
                box_spk.label(text="🔊 スタジオモニター・スピーカー設定:", icon='SPEAKER')
                box_spk.prop(props, "speaker_style", text="様式")
                box_spk.prop(props, "speaker_cone_color", text="コーン色")
                box_spk.prop(props, "speaker_scale", text="スケール")

                box_opt = box_spk.box()
                box_opt.label(text="パーツ・イルミネーション設定:", icon='LIGHT')
                box_opt.prop(props, "speaker_has_grille", text="保護サランネット (Grille)")
                box_opt.prop(props, "speaker_led_color", text="電源LED色")

                col_btn = box_spk.column(align=True)
                col_btn.scale_y = 1.3
                col_btn.operator("mesh.regenerate_speaker", text="🔄 再生成・更新 (選択中を更新)", icon='FILE_REFRESH')
                col_btn.operator("mesh.generate_speaker", text="＋ 新規スピーカーを生成", icon='ADD')

            # Wall Clock Specific
            elif props.prop_category == 'CLOCK':
                box_clock = layout.box()
                box_clock.label(text="🕰️ ローマ数字・壁掛け時計設定:", icon='TIME')
                box_clock.prop(props, "clock_shape", text="外枠形状")
                box_clock.prop(props, "clock_style", text="質感")
                box_clock.prop(props, "clock_diameter", text="直径 (m)")

                box_time = box_clock.box()
                box_time.label(text="⏰ 時刻設定 (時・分):", icon='PREVIEW_RANGE')
                row_t = box_time.row(align=True)
                row_t.prop(props, "clock_time_hour", text="時")
                row_t.prop(props, "clock_time_minute", text="分")

                box_opt = box_clock.box()
                box_opt.label(text="パーツ表示設定:", icon='HIDE_OFF')
                row_opt = box_opt.row(align=True)
                row_opt.prop(props, "clock_show_seconds", text="秒針")
                row_opt.prop(props, "clock_show_glass", text="風防ガラス")

                col_btn = box_clock.column(align=True)
                col_btn.scale_y = 1.3
                col_btn.operator("mesh.regenerate_wall_clock", text="🔄 再生成・更新 (選択中を更新)", icon='FILE_REFRESH')
                col_btn.operator("mesh.generate_wall_clock", text="＋ 新規壁掛け時計を生成", icon='ADD')

            # Flask & Potion Specific
            elif props.prop_category == 'FLASK':
                box_flask = layout.box()
                box_flask.label(text="🧪 魔法フラスコ・ポーション設定:", icon='MATERIAL')
                box_flask.prop(props, "flask_shape", text="形状")
                box_flask.prop(props, "flask_scale", text="スケール")
                box_flask.prop(props, "flask_has_cork", text="コルク栓を付ける")

                # 傾き設定
                box_tilt = box_flask.box()
                box_tilt.label(text="📐 容器の傾き & 液面の水平補正:", icon='ORIENTATION_LOCAL')
                box_tilt.prop(props, "flask_tilt", text="フラスコ傾き (度)", slider=True)
                box_tilt.prop(props, "liquid_tilt", text="液面水平補正 (度)", slider=True)

                # 液体設定
                box_liq = box_flask.box()
                box_liq.label(text="🌊 液体 & 表面歪み設定:", icon='MOD_OCEAN')
                box_liq.prop(props, "liquid_level", text="液面の高さ", slider=True)
                box_liq.prop(props, "liquid_surface_noise", text="表面波・歪み", slider=True)
                box_liq.prop(props, "liquid_color", text="液体の色")
                box_liq.prop(props, "liquid_glow", text="発光の強さ", slider=True)

                col_btn = box_flask.column(align=True)
                col_btn.scale_y = 1.3
                col_btn.operator("mesh.regenerate_flask_potion", text="🔄 再生成・更新 (選択中を更新)", icon='FILE_REFRESH')
                col_btn.operator("mesh.generate_flask_potion", text="＋ 新規フラスコを生成", icon='ADD')

            # Image Displace Studio Specific
            elif props.prop_category == 'IMAGE_DISPLACE':
                box_disp = layout.box()
                box_disp.label(text="Image Displace Studio (2D画像立体化):", icon='IMAGE_DATA')
                box_disp.prop(props, "img_disp_path", text="画像ファイル")
                row_quick = box_disp.row(align=True)
                row_quick.scale_y = 1.2
                row_quick.operator("mesh.import_clipboard_image", text="📋 クリップボードから貼り付け", icon='PASTEDOWN')
                row_quick.operator("mesh.import_dropped_image", text="🎯 ドロップ画像から取得", icon='IMPORT')
                box_disp.prop(props, "img_disp_shape", text="立体形状")
                box_disp.prop(props, "img_disp_mat_style", text="マテリアル質感")

                box_param = box_disp.box()
                box_param.label(text="🎛️ リアルタイム変位＆細分化 (Live Displace):", icon='MOD_DISPLACE')
                box_param.prop(props, "img_disp_subdiv_level", text="細分化レベル (Subdiv)")
                row_live = box_param.row(align=True)
                row_live.prop(props, "img_disp_strength", text="Strength (強さ)", slider=True)
                row_live.prop(props, "img_disp_midlevel", text="Midlevel (基準面)", slider=True)

                box_sm = box_disp.box()
                box_sm.label(text="🌊 スムース段差補正 (Smooth):", icon='MOD_SMOOTH')
                row_sm = box_sm.row(align=True)
                row_sm.prop(props, "img_disp_smooth_factor", text="強度 (Factor)", slider=True)
                row_sm.prop(props, "img_disp_smooth_iter", text="反復 (Iter)")

                box_cut = box_disp.box()
                box_cut.label(text="✂️ 型抜き＆色抜き (Live Cutout):", icon='SCULPTMODE_HLT')
                
                # 1. 高さ型抜き
                box_cut.prop(props, "img_disp_enable_cutout", text="同階層（高さ）を型抜き")
                if props.img_disp_enable_cutout:
                    row_cut = box_cut.row(align=True)
                    row_cut.prop(props, "img_disp_cutout_threshold", text="高さ閾値", slider=True)
                    row_cut.prop(props, "img_disp_cutout_invert", text="反転")

                # 2. 類似色型抜き
                box_cut.prop(props, "img_disp_enable_color_cutout", text="🎨 指定色で型抜き (Color Cutout)")
                if props.img_disp_enable_color_cutout:
                    box_col = box_cut.box()
                    row_col = box_col.row(align=True)
                    row_col.prop(props, "img_disp_key_color", text="対象色")
                    row_col.operator("mesh.auto_detect_background_color", text="🪄 自動取得", icon='COLOR')
                    box_col.prop(props, "img_disp_color_tolerance", text="色の許容差", slider=True)

                # 3. 両方ONの場合の併用モード
                if props.img_disp_enable_cutout and props.img_disp_enable_color_cutout:
                    box_cut.prop(props, "img_disp_cutout_mode", text="併用方式")

                box_cube = box_disp.box()
                box_cube.label(text="🧊 面・立体ブロック化 (Solidify / Cube):", icon='MESH_CUBE')
                box_cube.prop(props, "img_disp_solidify_thickness", text="厚み (Thickness)", slider=True)
                box_cube.prop(props, "img_disp_block_style", text="立体様式")

                box_opt = box_disp.box()
                box_opt.label(text="ゲーム最適化 & 超軽量化設定:", icon='MOD_DECIM')
                box_opt.prop(props, "img_disp_planar_angle", text="平面溶解の角度 (Angle)", slider=True)
                box_opt.prop(props, "img_disp_decimate_ratio", text="軽量化比率 (Decimate)", slider=True)
                box_opt.prop(props, "img_disp_close_mesh", text="裏面・底面を完全密閉 (Closed Solid)")

                row_opt_btn = box_opt.row(align=True)
                row_opt_btn.scale_y = 1.2
                row_opt_btn.operator("mesh.optimize_displace_mesh", text="⚡ 不要頂点消去 ＆ スマートUV化", icon='UV')

                col_btn = box_disp.column(align=True)
                col_btn.scale_y = 1.3
                col_btn.operator("mesh.generate_image_displace", text="🖼️ 2D画像から立体プレビュー生成", icon='MOD_DISPLACE')
                col_btn.operator("mesh.bake_game_ready_displace", text="🎮 ゲーム用確定 (裏面密閉 & 超軽量化)", icon='CHECKMARK')

            # Water Specific
            elif props.prop_category == 'WATER':
                box_water = layout.box()
                box_water.label(text="Water Settings (水面・池・湖設定):", icon='MOD_OCEAN')
                box_water.prop(props, "water_shape", text="形状プリセット")
                box_water.prop(props, "water_color_type", text="水質カラー")
                box_water.prop(props, "water_wave_strength", text="波の強さ (Bump)", slider=True)
                if props.water_shape == 'POND':
                    box_water.prop(props, "water_include_bed", text="🌿 泥砂利の池底スラブを生成")
                
                box_anim = layout.box()
                box_anim.label(text="🌊 湖面の微風アニメーション (Wind Animation):", icon='ANIM')
                box_anim.prop(props, "water_animate", text="微風アニメーションを有効化")
                if props.water_animate:
                    box_anim.prop(props, "water_wind_speed", text="風の強さ (Speed)")
                    box_anim.prop(props, "water_anim_frames", text="ループフレーム数")
                    box_anim.operator("mesh.export_animated_water_fbx", text="🎮 アニメーション付き水面FBXを出力", icon='EXPORT')

                box_sky = layout.box()
                box_sky.label(text="🌅 フォトリアル環境光 (Lighting & Sky):", icon='LIGHT_SUN')
                box_sky.operator("mesh.setup_water_sky_lighting", text="🌅 空と太陽光を自動セット (Nishita Sky)", icon='WORLD')

            # Pillar Specific
            elif props.prop_category == 'PILLAR':
                box_pillar = layout.box()
                box_pillar.label(text="Pillar Settings (柱・列柱設定):", icon='MOD_SOLIDIFY')
                box_pillar.prop(props, "pillar_type", text="様式タイプ")
                box_pillar.prop(props, "pillar_mat_type", text="石材マテリアル")
                if props.pillar_type == 'COURTYARD_CLASSIC':
                    box_pillar.prop(props, "pillar_flutes", text="縦溝の数 (Flutes)")
                    row_ped = box_pillar.row(align=True)
                    row_ped.prop(props, "pillar_pedestal_width", text="台座幅")
                    row_ped.prop(props, "pillar_pedestal_height", text="台座高")
                    box_pillar.prop(props, "pillar_include_railing", text="🏛️ 接続手すり・小支柱 (Balustrade)")
                    if props.pillar_include_railing:
                        box_pillar.prop(props, "pillar_railing_length", text="手すりの長さ (m)")
                elif props.pillar_type == 'GOTHIC_CLUSTERED':
                    box_pillar.prop(props, "pillar_colonnettes", text="小柱の数 (Colonnettes)")
                elif props.pillar_type == 'CLASSIC_FLUTED':
                    box_pillar.prop(props, "pillar_flutes", text="縦溝の数 (Flutes)")
                    box_pillar.prop(props, "pillar_entasis", text="エンタシス (Entasis)", slider=True)
            # Telescope Specific
            elif props.prop_category == 'TELESCOPE':
                box_tel = layout.box()
                box_tel.label(text="Telescope Settings (天体望遠鏡設定):", icon='CAMERA_DATA')
                box_tel.prop(props, "telescope_style", text="スタイル様式")
                box_tel.prop(props, "telescope_elevation_angle", text="🔭 仰角 (Elevation)", slider=True)
                box_tel.prop(props, "telescope_azimuth_angle", text="🧭 方位角 (Azimuth)", slider=True)
                box_tel.prop(props, "telescope_tripod_height", text="三脚の高さ")
                box_tel.prop(props, "telescope_tube_length", text="鏡筒の長さ")

            # Tree Specific
            elif props.prop_category == 'TREE':
                box_tree = layout.box()
                box_tree.label(text="Tree Settings (リアル樹木設定):", icon='OUTLINER_OB_LIGHT')
                box_tree.prop(props, "tree_species", text="樹種")
                box_tree.prop(props, "tree_material_mode", text="マテリアル方式")
                box_tree.prop(props, "tree_branch_levels", text="枝分かれ深さ")
                box_tree.prop(props, "tree_curvature", text="枝のうねり・曲がり", slider=True)
                box_tree.prop(props, "tree_has_leaves", text="🍃 葉を付ける")
                if props.tree_has_leaves:
                    box_tree.prop(props, "tree_leaf_style", text="葉のスタイル")
                    box_tree.prop(props, "tree_leaf_count", text="葉の密度")

            # Bush Specific
            elif props.prop_category == 'BUSH':
                box_bush = layout.box()
                box_bush.label(text="🌿 低木・茂み・シダ設定 (Bush & Foliage):", icon='OUTLINER_OB_CURVE')
                box_bush.prop(props, "bush_type", text="タイプ")
                box_bush.prop(props, "bush_density", text="密度 (Density)")
                box_bush.prop(props, "bush_leaf_size", text="葉サイズ (Size)")
                if props.bush_type == 'FERN_CLUMP':
                    box_bush.prop(props, "bush_include_fiddleheads", text="🌀 ゼンマイ新芽を付ける")

            # Chair Specific
            elif props.prop_category in ('CHAIR', 'OFFICE_CHAIR'):
                box_chair = layout.box()
                box_chair.label(text="Chair Settings (椅子設定):", icon='PASTEDOWN')
                box_chair.prop(props, "chair_type", text="タイプ")
                if props.chair_type in ('DINING_CHAIR', 'ARMCHAIR', 'ROUND_STOOL', 'SQUARE_STOOL'):
                    box_chair.prop(props, "chair_seat_style", text="座面")
                    if props.chair_type in ('DINING_CHAIR', 'ARMCHAIR'):
                        box_chair.prop(props, "chair_back_style", text="背もたれ")
                    box_chair.prop(props, "chair_leg_layout", text="脚の構造")
                    box_chair.prop(props, "table_leg_style", text="脚の装飾")
                box_chair.prop(props, "rand_furniture_style", text="🎲 スタイルランダム")

            # Table Specific
            elif props.prop_category in ('TABLE', 'PC_DESK'):
                box_tab = layout.box()
                box_tab.label(text="Table / Desk Settings (机・デスク設定):", icon='WORKSPACE')
                box_tab.prop(props, "table_shape", text="天板形状")
                box_tab.prop(props, "table_leg_style", text="脚の形状・フレーム")
                box_tab.prop(props, "rand_furniture_style", text="🎲 スタイルランダム")

            # Chest Specific
            elif props.prop_category == 'CHEST':
                box_chest = layout.box()
                box_chest.label(text="Chest Settings (タンス設定):", icon='FILE_ARCHIVE')
                box_chest.prop(props, "chest_tiers", text="引き出し段数 (2~5段)")
                box_chest.prop(props, "chest_handle_style", text="取っ手金具")
                box_chest.prop(props, "rand_furniture_style", text="🎲 スタイルランダム")

            # Bed Specific
            elif props.prop_category == 'BED':
                box_bed = layout.box()
                box_bed.label(text="Bed Settings (ベッド設定):", icon='COMMUNITY')
                box_bed.prop(props, "bed_size", text="サイズ")
                box_bed.prop(props, "column_ornament_style", text="四隅ポスト装飾")
                box_bed.prop(props, "rand_furniture_style", text="🎲 スタイルランダム")

            # Dictionary Specific
            elif props.prop_category == 'DICTIONARY':
                box_dict = layout.box()
                box_dict.label(text="Dictionary Settings (中性的辞書設定):", icon='BOOKMARKS')
                box_dict.prop(props, "dictionary_color_preset", text="表紙カラー")
                box_dict.prop(props, "dictionary_rib_count", text="背リブ本数")
                box_dict.prop(props, "dictionary_has_ribbon", text="しおり紐")
                box_dict.prop(props, "dictionary_page_aging", text="⌛ 紙の年季・黄ばみ度", slider=True)
                
                box_runes = box_dict.box()
                box_runes.label(text="謎文字・古代グリフ装飾:", icon='FONT_DATA')
                box_runes.prop(props, "dictionary_has_runes", text="表紙・背に謎文字を刻印")
                if props.dictionary_has_runes:
                    box_runes.prop(props, "dictionary_foil_style", text="箔様式")
                    box_runes.prop(props, "dictionary_rune_intensity", text="刻印の鮮明度", slider=True)

                box_adv = box_dict.box()
                box_adv.label(text="製本カーブ微調整:", icon='SURFACE_NCURVE')
                box_adv.prop(props, "dictionary_spine_curvature", text="背の丸み")
                box_adv.prop(props, "dictionary_fore_edge_hollow", text="小口の凹み")

                row_reroll = box_dict.row(align=True)
                row_reroll.scale_y = 1.3
                row_reroll.operator("mesh.reroll_selected_prop", text="🎲 ランダム再抽選 (大きさ・厚み・色)", icon='FILE_REFRESH')

            # Bookshelf Specific
            elif props.prop_category == 'BOOKSHELF':
                box_shelf = layout.box()
                box_shelf.label(text="Bookshelf Settings (本棚設定):", icon='BOOKMARKS')
                box_shelf.prop(props, "shelf_tiers", text="棚段数 (2~4段)")
                box_shelf.prop(props, "column_ornament_style", text="側柱の装飾")
                box_shelf.prop(props, "rand_furniture_style", text="🎲 スタイルランダム")

            # Bush Specific
            elif props.prop_category == 'BUSH':
                box_bush = layout.box()
                box_bush.label(text="Bush & Shrub Settings (低木・茂み設定):", icon='FORCE_FORCE')
                box_bush.prop(props, "bush_type", text="")
                box_bush.prop(props, "bush_foliage_style", text="葉スタイル")
                box_bush.prop(props, "bush_density", text="密度 (Density)")
                box_bush.prop(props, "bush_leaf_size", text="葉サイズ (Leaf Size)")

            # Fence Specific
            elif props.prop_category == 'FENCE':
                box_fence = layout.box()
                box_fence.label(text="🚧 実用フェンス・金網プリセット (Modern & Wood):", icon='SNAP_INCREMENT')
                box_fence.prop(props, "fence_preset_type", text="様式")

                # 寸法・形状パラメータ
                box_dim = box_fence.box()
                box_dim.label(text="📐 フェンス寸法 & スパン設定:", icon='ARROW_LEFTRIGHT')
                box_dim.prop(props, "fence_length", text="全長 (m)")
                box_dim.prop(props, "fence_height", text="高さ (m)")
                box_dim.prop(props, "fence_post_spacing", text="支柱スパン (m)")
                if props.fence_preset_type in ('WOOD_HORIZ', 'WOOD_VERT'):
                    box_dim.prop(props, "fence_slat_gap", text="木板の隙間 (m)")
                box_dim.prop(props, "fence_scale", text="スケール")

                # 🪵 木板リアル化 & 経年劣化設定 (WOOD_HORIZ / WOOD_VERT 用)
                if props.fence_preset_type in ('WOOD_HORIZ', 'WOOD_VERT'):
                    box_wood = box_fence.box()
                    box_wood.label(text="🪵 木板リアル化 & 経年劣化 (Realism):", icon='MOD_EDGESPLIT')
                    if props.fence_preset_type == 'WOOD_VERT':
                        box_wood.prop(props, "fence_wood_top_style", text="上部形状")
                    box_wood.prop(props, "fence_wood_jitter", text="ゆがみ・反り", slider=True)
                    box_wood.prop(props, "fence_wood_wear", text="角欠け・劣化", slider=True)
                    box_wood.prop(props, "fence_wood_weathering", text="木目・汚し", slider=True)

                # 🎨 カラー・質感設定 (支柱・鉄線・板の色分け)
                box_color = box_fence.box()

                box_color.label(text="🎨 カラー & 質感設定 (支柱・鉄線・木板):", icon='COLOR')
                box_color.prop(props, "fence_color_preset", text="パレット")
                row_col = box_color.row(align=True)
                row_col.prop(props, "fence_frame_color", text="支柱色")
                row_col.prop(props, "fence_body_color", text="鉄線/板色")
                row_mat = box_color.row(align=True)
                row_mat.prop(props, "fence_metallic", text="金属感", slider=True)
                row_mat.prop(props, "fence_roughness", text="粗さ", slider=True)
                box_color.operator("mesh.apply_fence_colors", text="🎨 選択中フェンスに色を即時反映", icon='RESTRICT_COLOR_ON')

                # 一発生成 & 再生成ボタン（その場更新）
                col_btn = box_fence.column(align=True)
                col_btn.scale_y = 1.3
                col_btn.operator("mesh.regenerate_fence_preset", text="🔄 再生成・更新 (選択中を更新)", icon='FILE_REFRESH')
                col_btn.operator("mesh.generate_fence_preset", text="➕ 新規フェンスを生成", icon='ADD')


                # 従来のクラシック木製柵（サブ設定）
                box_legacy = box_fence.box()
                box_legacy.label(text="🪵 クラシック牧場柵・防壁 (Legacy):", icon='DECORATE')
                box_legacy.prop(props, "fence_type", text="様式")
                if props.fence_type == 'POST_AND_RAIL':
                    box_legacy.prop(props, "fence_rails_count", text="横木の段数")
                box_legacy.prop(props, "fence_post_spacing", text="支柱の間隔")
                box_legacy.prop(props, "fence_decay_jitter", text="経年劣化・歪み", slider=True)


            # Grass & Biome Specific
            elif props.prop_category == 'GRASS':
                # 🌟 1. 内蔵バイオームスキャッター (Geometry Nodes 自己完結型)
                box_biome = layout.box()
                box_biome.label(text="🌿 リアル自然・バイオーム散布 (Nature Biome Scatter):", icon='NODETREE')
                box_biome.prop(props, "biome_type", text="バイオーム")

                box_b_param = box_biome.box()
                box_b_param.label(text="📐 散布・テレイン設定 (Poisson Disk):", icon='MOD_PARTICLES')
                row_bp1 = box_b_param.row(align=True)
                row_bp1.prop(props, "biome_density", text="密度 (Density)")
                row_bp1.prop(props, "biome_min_dist", text="最小離隔 (m)")
                row_bp2 = box_b_param.row(align=True)
                row_bp2.prop(props, "biome_terrain_size", text="規模 (m)")
                row_bp2.prop(props, "biome_undulation", text="起伏 (Undulation)")

                box_b_assets = box_biome.box()
                box_b_assets.label(text="🌱 アセット混入設定:", icon='GROUP')
                row_ba = box_b_assets.row(align=True)
                row_ba.prop(props, "biome_include_fern", text="シダ・新芽")
                row_ba.prop(props, "biome_include_shrub", text="小低木")
                row_ba.prop(props, "biome_include_pebble", text="小石")

                col_b_btn = box_biome.column(align=True)
                col_b_btn.scale_y = 1.3
                col_b_btn.operator("mesh.regenerate_biome_scatter", text="🔄 再生成・更新 (選択中を更新)", icon='FILE_REFRESH')
                col_b_btn.operator("mesh.create_biome_scatter", text="➕ 新規バイオームを生成", icon='ADD')
                col_b_btn.separator()
                col_b_btn.operator("mesh.convert_scatter_to_game_mesh", text="🎮 ゲーム用実体メッシュへ変換 (Make Real)", icon='CHECKMARK')

                # 🌟 2. 従来のヘアパーティクル式 草原（サブ設定）
                box_legacy = layout.box()
                box_legacy.label(text="🌾 クラシック草原パーティクル (Legacy Hair):", icon='OUTLINER_OB_POINTCLOUD')
                box_legacy.prop(props, "grass_mode", text="草タイプ")
                if props.grass_mode == 'MOUND':
                    box_legacy.prop(props, "terrain_type", text="地形")
                    box_legacy.prop(props, "floor_shape", text="床形状")
                box_legacy.prop(props, "grass_density", text="草の本数 (Count)")
                box_legacy.prop(props, "grass_undulation", text="起伏 (Undulation)")
                box_legacy.operator("mesh.create_grass_field", text="🌾 クラシック草原を生成", icon='PARTICLE_DATA')
                box_legacy.operator("mesh.convert_grass_to_game_mesh", text="🎮 実体化メッシュへ変換", icon='MESH_DATA')

            # Floor Specific
            elif props.prop_category == 'FLOOR':
                box_fshape = layout.box()
                box_fshape.label(text="Floor Shape (床の形状):", icon='MESH_PLANE')
                box_fshape.prop(props, "floor_shape", text="")
                if props.floor_shape == 'COBBLESTONE':
                    box_fshape.prop(props, "cobble_stone_size", text="石の大きさ (Stone Size)")
                    box_fshape.prop(props, "cobble_grout_depth", text="目地の深さ (Grout Depth)")
                    box_fshape.prop(props, "cobble_jitter", text="歪み・凹凸 (Jitter)", slider=True)

            # Wall Specific
            elif props.prop_category == 'WALL':
                box_wshape = layout.box()
                box_wshape.label(text="Wall Shape (壁の形状):", icon='MESH_CUBE')
                box_wshape.prop(props, "wall_shape", text="")
                if props.wall_shape == 'COBBLE_WALL':
                    box_wshape.prop(props, "cobble_stone_size", text="石の大きさ (Stone Size)")
                    box_wshape.prop(props, "cobble_jitter", text="突出・歪み (Jitter)", slider=True)

            # Castle Wall (Stone Scatter) Specific
            elif props.prop_category == 'CASTLE_WALL':
                box_cwall = layout.box()
                box_cwall.label(text="🏰 中世城壁・石積み壁 (Castle Stone Wall):", icon='MOD_BUILD')
                box_cwall.prop(props, "castle_wall_shape", text="城壁形状")
                box_cwall.prop(props, "castle_wall_style", text="石積み様式")

                # 石材ブロック自体の形状設定
                box_cw_stone = box_cwall.box()
                box_cw_stone.label(text="🧱 石材ブロック自体の形状調整:", icon='MESH_ICOSPHERE')
                box_cw_stone.prop(props, "castle_wall_stone_aspect", text="プロポーション")
                row_cws_shp = box_cw_stone.row(align=True)
                row_cws_shp.prop(props, "castle_wall_stone_roundness", text="角の丸み", slider=True)
                row_cws_shp.prop(props, "castle_wall_stone_chipping", text="チゼル欠け", slider=True)

                # 寸法設定
                box_cw_dim = box_cwall.box()
                box_cw_dim.label(text="📐 城壁寸法 & 胸壁設定:", icon='ARROW_LEFTRIGHT')
                box_cw_dim.prop(props, "castle_wall_randomize_dimensions", text="🎲 Re-Roll時に寸法もランダム化")
                row_cw1 = box_cw_dim.row(align=True)
                row_cw1.enabled = not props.castle_wall_randomize_dimensions
                row_cw1.prop(props, "castle_wall_length", text="長さ (m)")
                row_cw1.prop(props, "castle_wall_height", text="高さ (m)")
                row_cw1.prop(props, "castle_wall_thickness", text="厚み (m)")
                if props.castle_wall_shape in ('STRAIGHT', 'BATTLEMENT', 'RANDOM'):
                    box_cw_dim.prop(props, "castle_wall_has_crenels", text="🛡️ 銃眼胸壁 (Crenels / 狭間) を付ける")

                # 土台メッシュ形状設定（歪み・傾き・出っ張り）
                box_cw_base = box_cwall.box()
                box_cw_base.label(text="🏔️ 土台の自然な起伏・歪み設定:", icon='MOD_DISPLACE')
                row_cwb = box_cw_base.row(align=True)
                row_cwb.prop(props, "castle_wall_batter", text="裾広がり傾斜 (Batter)", slider=True)
                row_cwb.prop(props, "castle_wall_roughness", text="出っ張り・うねり", slider=True)

                # 散布設定
                box_cw_scat = box_cwall.box()
                box_cw_scat.label(text="🧱 石材散布 & 単一メッシュ結合設定:", icon='MOD_PARTICLES')
                row_cws = box_cw_scat.row(align=True)
                row_cws.prop(props, "castle_wall_density", text="石材密度")
                row_cws.prop(props, "castle_wall_min_dist", text="最小間隔 (m)")
                box_cw_scat.prop(props, "castle_wall_jitter", text="凹凸・飛び出し (Jitter)", slider=True)
                box_cw_scat.prop(props, "castle_wall_combine", text="🎮 1つのStatic Meshに結合 (確定)")

                # 操作ボタン
                col_cw_btn = box_cwall.column(align=True)
                col_cw_btn.scale_y = 1.3
                col_cw_btn.operator("mesh.reroll_castle_wall", text="🎲 形状・石材を全再抽選 (Re-Roll All)", icon='FILE_REFRESH')
                col_cw_btn.operator("mesh.regenerate_castle_wall", text="🔄 現在の設定で更新 (その場更新)", icon='FILE_CACHE')
                col_cw_btn.operator("mesh.create_castle_wall", text="➕ 新規城壁を生成", icon='ADD')
                if not props.castle_wall_combine:
                    col_cw_btn.separator()
                    col_cw_btn.operator("mesh.convert_castle_wall_to_game_mesh", text="🎮 手動でゲーム用実体メッシュへ変換", icon='CHECKMARK')


            # Cave Floor (New Terrain) Preset Specific
            elif props.prop_category == 'CAVE_FLOOR':
                box_cf = layout.box()
                box_cf.label(text="🪨 洞窟床・新テレイン (なだらか傾斜 & ソリッド大地スラブ):", icon='MESH_GRID')

                # 0. 岩肌スタイル & ルート形状
                box_cf_style = box_cf.box()
                box_cf_style.prop(props, "cave_rock_style", text="🎨 岩肌スタイル")
                box_cf_style.prop(props, "cave_path_type", text="ルート形状")
                row_moss = box_cf_style.row(align=True)
                row_moss.prop(props, "cave_add_moss", text="🌿 苔を生やす (Moss)", toggle=True)
                if props.cave_add_moss:
                    row_moss.prop(props, "cave_moss_amount", text="苔の量", slider=True)

                # 1. 水面設定 (リアルな地下水流・川の有無)
                box_cf_water = box_cf.box()
                row_r_tog = box_cf_water.row(align=True)
                row_r_tog.prop(props, "cave_has_river", text="💧 地下水流・川を生成 (River Trench)", toggle=True)
                if props.cave_has_river:
                    row_r = box_cf_water.row(align=True)
                    row_r.prop(props, "cave_river_width", text="川幅 (m)")
                    row_r.prop(props, "cave_river_depth", text="谷の深さ (m)")

                # 2. フロア寸法 & 起伏 (100x100mなどの大規模テレインに対応)
                box_cf_dim = box_cf.box()
                box_cf_dim.label(text="📐 フロア寸法 & 起伏設定 (矩形モジュラー境界):", icon='ARROW_LEFTRIGHT')
                row_cf_d1 = box_cf_dim.row(align=True)
                row_cf_d1.prop(props, "cave_floor_width", text="全幅 (m)")
                row_cf_d1.prop(props, "cave_floor_length", text="全長 (m)")
                row_cf_d2 = box_cf_dim.row(align=True)
                row_cf_d2.prop(props, "cave_roughness", text="断層起伏 (Roughness)", slider=True)

                # 特徴ヒント
                box_cf_hint = box_cf.box()
                box_cf_hint.label(text="✨ 外周4辺は完全な直線矩形（歪みゼロ・UE上でタイル配置時に空白地なし）", icon='INFO')
                box_cf_hint.label(text="   厚み1.2mのソリッド基盤スラブ＋蛇行川トレンチ（水たまりはオミット済み）")

                # 操作ボタン
                col_cf_btn = box_cf.column(align=True)
                col_cf_btn.scale_y = 1.3
                col_cf_btn.operator("mesh.reroll_cave", text="🎲 床を再抽選 (Re-Roll)", icon='FILE_REFRESH')
                col_cf_btn.operator("mesh.regenerate_cave", text="🔄 現在の設定で更新 (その場更新)", icon='FILE_CACHE')
                col_cf_btn.operator("mesh.create_cave", text="➕ 新規洞窟床を生成", icon='ADD')

            # Cave Preset Specific
            elif props.prop_category == 'CAVE':
                box_cave = layout.box()
                box_cave.label(text="🪨 洞窟・岩窟ジオラマ (岩棚テラス＆水流トレンチ):", icon='MOD_BUILD')

                # 0. ルート形状 & 岩肌・苔スタイル
                box_c_style = box_cave.box()
                box_c_style.prop(props, "cave_path_type", text="ルート形状")
                box_c_style.prop(props, "cave_rock_style", text="岩肌スタイル")
                row_moss = box_c_style.row(align=True)
                row_moss.prop(props, "cave_add_moss", text="🌿 苔を生やす (Moss)", toggle=True)
                if props.cave_add_moss:
                    row_moss.prop(props, "cave_moss_amount", text="苔の量", slider=True)

                # 1. 水面設定 (水たまり・河川・併用・なし)
                box_c_river = box_cave.box()
                box_c_river.prop(props, "cave_water_type", text="水面タイプ")
                if props.cave_water_type in ('RIVER', 'BOTH'):
                    row_cr_params = box_c_river.row(align=True)
                    row_cr_params.prop(props, "cave_river_width", text="川幅 (m)")
                    row_cr_params.prop(props, "cave_river_depth", text="谷の深さ (m)")
                if props.cave_water_type in ('PUDDLES', 'BOTH'):
                    row_cp_params = box_c_river.row(align=True)
                    row_cp_params.prop(props, "cave_puddle_count", text="水たまり数")
                    row_cp_params.prop(props, "cave_puddle_scale", text="規模 (m)")

                # 2. 岩棚（テラス）＆フロア寸法設定
                box_c_dim = box_cave.box()
                box_c_dim.label(text="📐 岩棚テラス & フロア寸法:", icon='ARROW_LEFTRIGHT')
                row_cd1 = box_c_dim.row(align=True)
                row_cd1.prop(props, "cave_floor_width", text="全幅 (m)")
                row_cd1.prop(props, "cave_floor_length", text="全長 (m)")

                row_cd2 = box_c_dim.row(align=True)
                row_cd2.prop(props, "cave_terrace_steps", text="岩棚段数")
                row_cd2.prop(props, "cave_roughness", text="断層起伏 (Roughness)", slider=True)

                # 3. 天井・断崖側壁設定 (Step 2)
                box_c_ceil = box_cave.box()
                row_cc = box_c_ceil.row(align=True)
                row_cc.prop(props, "cave_generate_ceiling", text="🏛️ 天井・断崖壁を生成 (Ceiling & Cliffs)", toggle=True)
                if props.cave_generate_ceiling:
                    row_cc1 = box_c_ceil.row(align=True)
                    row_cc1.prop(props, "cave_ceiling_height", text="天井高 (m)")
                    row_cc1.prop(props, "cave_ceiling_overhang", text="せり出し度", slider=True)

                    row_cc2 = box_c_ceil.row(align=True)
                    row_cc2.prop(props, "cave_ceiling_fissure", text="天窓亀裂 (m)")
                    row_cc2.prop(props, "cave_ceiling_roughness", text="天井起伏", slider=True)

                # 4. 地質装飾 (Step 3: 岩柱・鍾乳石・石筍・崩落瓦礫)
                box_c_feat = box_cave.box()
                box_c_feat.label(text="地質装飾 (岩柱・鍾乳石・瓦礫):", icon='SNAP_VOLUME')
                
                row_cp = box_c_feat.row(align=True)
                row_cp.prop(props, "cave_generate_pillars", text="🏛️ 天地貫通の岩柱 (Pillars)", toggle=True)
                if props.cave_generate_pillars:
                    row_cp.prop(props, "cave_pillar_count", text="本数")

                row_cs = box_c_feat.row(align=True)
                row_cs.prop(props, "cave_generate_stalactites", text="🧊 鍾乳石・石筍 (Speleothems)", toggle=True)
                if props.cave_generate_stalactites:
                    row_cs.prop(props, "cave_stalactite_density", text="密度倍率")

                row_cb = box_c_feat.row(align=True)
                row_cb.prop(props, "cave_generate_boulders", text="🪨 崩落巨石・瓦礫 (Debris)", toggle=True)
                if props.cave_generate_boulders:
                    row_cb.prop(props, "cave_boulder_count", text="個数")

                # 5. 洞窟内部ライティング設定
                box_c_light = box_cave.box()
                row_cl = box_c_light.row(align=True)
                row_cl.prop(props, "cave_setup_lights", text="💡 洞窟ライトを自動配置 (Auto Lights)", toggle=True)
                if props.cave_setup_lights:
                    box_c_light.prop(props, "cave_light_intensity", text="明るさ倍率", slider=True)

                box_cave.prop(props, "cave_randomize_shape", text="🎲 Re-Roll時に幅・段差も自動抽選")

                # 構造ヒント
                box_c_hint = box_cave.box()
                box_c_hint.label(text="💡 Floor / Water / Ceiling / Pillars / Debris が階層分離生成されます", icon='INFO')
                box_c_hint.label(text="   天井を非表示(Hキー)にするとフロアや岩柱の内部が丸見えになります")

                # 操作ボタン
                col_c_btn = box_cave.column(align=True)
                col_c_btn.scale_y = 1.3
                col_c_btn.operator("mesh.reroll_cave", text="🎲 洞窟フロアを再抽選 (Re-Roll All)", icon='FILE_REFRESH')
                col_c_btn.operator("mesh.regenerate_cave", text="🔄 現在の設定で更新 (その場更新)", icon='FILE_CACHE')
                col_c_btn.operator("mesh.create_cave", text="➕ 新規洞窟フロアを生成", icon='ADD')

            # Stone Arch & Colonnade Preset Specific
            elif props.prop_category == 'BEAM_ARCH':
                box_arch = layout.box()
                box_arch.label(text="🏛️ 建築アーチ・回廊 (Stone Arch / Colonnade):", icon='MOD_BUILD')

                # 1. 様式 & 構造タイプ
                box_a_style = box_arch.box()
                box_a_style.prop(props, "arch_style", text="様式")
                box_a_style.prop(props, "arch_structure_type", text="構造")
                if props.arch_structure_type == 'COLONNADE':
                    box_a_style.prop(props, "arch_span_count", text="連続スパン数 (2~8)")

                # 2. 支柱 & 台座設定
                box_a_pier = box_arch.box()
                box_a_pier.label(text="支柱・台座設定 (Piers & Plinths):", icon='SNAP_VOLUME')
                box_a_pier.prop(props, "arch_pillar_shape", text="柱の断面形状")
                row_p_dim = box_a_pier.row(align=True)
                row_p_dim.prop(props, "arch_pillar_width", text="太さ (m)")
                row_p_dim.prop(props, "arch_column_height", text="長さ/高さ (m)")
                row_ped = box_a_pier.row(align=True)
                row_ped.prop(props, "arch_has_pedestal", text="🏛️ 柱脚台座 (Plinth Base)", toggle=True)

                # 3. 装飾モールディング & 要石
                box_a_decor = box_arch.box()
                box_a_decor.label(text="装飾モールディング & 要石:", icon='MOD_SUBSURF')
                box_a_decor.prop(props, "arch_molding_tiers", text="段数 (Tiers)")
                row_key = box_a_decor.row(align=True)
                row_key.prop(props, "arch_has_keystone", text="🏛️ 要石 (Keystone)", toggle=True)
                if props.arch_has_keystone:
                    row_key.prop(props, "arch_keystone_scale", text="突出倍率")

                # 4. スパンドレル壁
                box_a_span = box_arch.box()
                box_a_span.prop(props, "arch_has_spandrel", text="🧱 上部スパンドレル壁 & コーニス天板", toggle=True)

                # 5. 経年風化・汚し & 欠け設定
                box_a_weath = box_arch.box()
                box_a_weath.label(text="経年風化・汚し & 欠け (Aging & Wear):", icon='BRUSH_DATA')
                box_a_weath.prop(props, "arch_damage", text="🧱 経年欠け・チッピング", slider=True)
                box_a_weath.prop(props, "arch_weathering", text="🌧️ 汚し・風化 (AO/雨垂れ)", slider=True)
                box_a_weath.prop(props, "arch_moss_amount", text="🌿 足元の苔・湿気", slider=True)

                # 特徴ヒント
                box_a_hint = box_arch.box()
                box_a_hint.label(text="💡 hbitproject式 建築プロポーション＆要石・多段モールディング", icon='INFO')
                box_a_hint.label(text="   外周はモジュラー壁や上階と完全フラットに接合できる形状です")

                col_a_btn = box_arch.column(align=True)
                col_a_btn.scale_y = 1.3
                col_a_btn.operator("mesh.update_selected_prop", text="🔄 パラメータを反映・更新 (選択中を更新)", icon='FILE_REFRESH')
                row_a_sub = col_a_btn.row(align=True)
                row_a_sub.operator("mesh.reroll_selected_prop", text="🎲 形状を再抽選 (Re-Roll)", icon='DICE')
                row_a_sub.operator("mesh.create_new_prop", text="➕ 新規アーチを生成", icon='ADD')

            # Modular Relief Wall Preset Specific
            elif props.prop_category == 'RELIEF_WALL':
                box_rw = layout.box()
                box_rw.label(text="🏛️ モジュラー・レリーフ壁 (Modular Relief Wall):", icon='MOD_BUILD')

                # 1. レリーフ様式 & 連続スパン数
                box_rw_style = box_rw.box()
                box_rw_style.prop(props, "relief_style", text="レリーフ様式")
                if props.relief_style == 'CUSTOM':
                    box_rw_style.prop(props, "relief_custom_image", text="画像パス")
                box_rw_style.prop(props, "relief_wall_bays", text="連続数 (Bays / Array)")
                box_rw_style.prop(props, "relief_depth", text="彫りの深さ (m)")

                # 2. ピラスター（付け柱）& 額縁モールディング設定
                box_rw_frame = box_rw.box()
                box_rw_frame.label(text="ピラスター & 額縁モールディング:", icon='SNAP_VOLUME')
                row_rw_p = box_rw_frame.row(align=True)
                row_rw_p.prop(props, "relief_pilaster_width", text="柱幅 (m)")
                row_rw_p.prop(props, "relief_pilaster_depth", text="突出厚 (m)")
                box_rw_frame.prop(props, "relief_frame_bevel", text="額縁幅 (m)")

                # 3. 経年風化・汚し & 欠け設定
                box_rw_weath = box_rw.box()
                box_rw_weath.label(text="経年風化・汚し & 欠け (Aging & Wear):", icon='BRUSH_DATA')
                box_rw_weath.prop(props, "relief_damage", text="🧱 経年欠け・チッピング", slider=True)
                box_rw_weath.prop(props, "relief_weathering", text="🌧️ 汚し・風化 (AO/雨垂れ)", slider=True)
                box_rw_weath.prop(props, "relief_moss_amount", text="🌿 足元の苔・湿気", slider=True)

                # 特徴ヒント
                box_rw_hint = box_rw.box()
                box_rw_hint.label(text="💡 モジュラー設計: 左右端の半幅ピラスターが並べた瞬間に合体します", icon='INFO')
                box_rw_hint.label(text="   X境界は完全フラットスナップ面を維持し、継ぎ目が完全に隠れます")

                col_rw_btn = box_rw.column(align=True)
                col_rw_btn.scale_y = 1.3
                col_rw_btn.operator("mesh.update_selected_prop", text="🔄 パラメータを反映・更新 (選択中を更新)", icon='FILE_REFRESH')
                row_rw_sub = col_rw_btn.row(align=True)
                row_rw_sub.operator("mesh.reroll_selected_prop", text="🎲 形状を再抽選 (Re-Roll)", icon='DICE')
                row_rw_sub.operator("mesh.create_new_prop", text="➕ 新規レリーフ壁を生成", icon='ADD')

            # Realistic Western Window Preset Specific
            elif props.prop_category == 'WINDOW':
                box_win = layout.box()
                box_win.label(text="🪟 リアル西洋窓 (Western Architectural Window):", icon='MOD_BUILD')

                # 1. 窓枠形状 & アーチ様式
                box_w_style = box_win.box()
                box_w_style.prop(props, "window_frame_style", text="窓枠形状")
                if props.window_frame_style in ('GOTHIC_POINTED', 'ROMAN_ROUND', 'TUDOR', 'ROUND_ARCH', 'POINTED_ARCH'):
                    box_w_style.prop(props, "window_arch_style", text="アーチ様式")
                    if props.window_arch_style == 'RADIAL_ASHLAR':
                        box_w_style.prop(props, "window_has_keystone", text="中央要石 (Keystone)")
                box_w_style.prop(props, "window_grille_style", text="格子・針金様式")

                # 2. 側枠・支柱スタイル (Jamb & Column)
                box_w_jamb = box_win.box()
                box_w_jamb.label(text="🏛️ 側枠・支柱スタイル (Jamb & Column):", icon='SNAP_VOLUME')
                box_w_jamb.prop(props, "window_jamb_style", text="支柱様式")
                if props.window_jamb_style == 'ENGAGED_FLUTED':
                    row_fl = box_w_jamb.row(align=True)
                    row_fl.prop(props, "window_column_flutes", text="縦溝の数 (Flutes)")
                    row_fl.prop(props, "window_column_pedestal", text="クラシック台座")
                elif props.window_jamb_style == 'PILASTER_PANEL':
                    box_w_jamb.prop(props, "window_column_pedestal", text="クラシック台座")

                # 2. 格子・針金ディテール
                if props.window_grille_style != 'PLAIN':
                    box_w_grille = box_win.box()
                    box_w_grille.label(text="格子・針金ディテール (Grille & Wire):", icon='SNAP_VOLUME')
                    row_wg = box_w_grille.row(align=True)
                    row_wg.prop(props, "window_wire_density", text="針金密度/本数")
                    row_wg.prop(props, "window_wire_thickness", text="線の太さ (m)")

                # 3. 外枠石枠 & コーニス・窓台
                box_w_frame = box_win.box()
                box_w_frame.label(text="石枠・窓台・コーニス (Frame & Sill):", icon='MESH_CUBE')
                box_w_frame.prop(props, "window_frame_width", text="外枠の幅 (m)")
                row_wf = box_w_frame.row(align=True)
                row_wf.prop(props, "window_has_sill", text="🏛️ 窓台 (Stone Sill)", toggle=True)
                row_wf.prop(props, "window_has_hood", text="🏛️ 水切りコーニス (Hood)", toggle=True)

                # 4. 経年風化・汚し & 欠け設定
                box_w_weath = box_win.box()
                box_w_weath.label(text="経年風化・汚し & 欠け (Aging & Wear):", icon='BRUSH_DATA')
                box_w_weath.prop(props, "window_damage", text="🧱 経年欠け・チッピング", slider=True)
                box_w_weath.prop(props, "window_weathering", text="🌧️ 汚し・風化 (AO/雨垂れ)", slider=True)
                box_w_weath.prop(props, "window_moss_amount", text="🌿 窓台の苔・湿気", slider=True)

                # 5. 🚪 UE開閉インタラクション＆サッシュ設定
                box_w_sash = box_win.box()
                box_w_sash.label(text="🚪 UE開閉インタラクション・サッシュ設定:", icon='OBJECT_DATAMODE')
                box_w_sash.prop(props, "window_sash_mode", text="開閉方式")
                if props.window_sash_mode != 'FIXED':
                    box_w_sash.prop(props, "window_open_angle", text="開閉角度 (プレビュー)", slider=True)
                    row_sdir = box_w_sash.row(align=True)
                    row_sdir.prop(props, "window_open_direction", text="開閉方向")
                    row_sdir.prop(props, "window_has_handle", text="クレモン錠ハンドル")
                    box_w_sash.prop(props, "window_has_hinges", text="蝶番金具 (Hinges)")
                box_w_sash.prop(props, "window_sash_material", text="サッシュ材質")
                box_w_sash.prop(props, "window_combine", text="単一メッシュ結合 (UE開閉時はOFF)")

                # 特徴ヒント
                box_w_hint = box_win.box()
                box_w_hint.label(text="💡 【UE開閉対応】蝶番の回転軸(Pivot)が正確に配置された親子階層で出力されます", icon='INFO')
                box_w_hint.label(text="   UE側で Relative Rotation (Yaw) を回すだけで実物通りに開閉します")

                col_w_btn = box_win.column(align=True)
                col_w_btn.scale_y = 1.3
                col_w_btn.operator("mesh.update_selected_prop", text="🔄 パラメータを反映・更新 (選択中を更新)", icon='FILE_REFRESH')
                row_w_sub = col_w_btn.row(align=True)
                row_w_sub.operator("mesh.reroll_selected_prop", text="🎲 形状を再抽選 (Re-Roll)", icon='DICE')
                row_w_sub.operator("mesh.create_new_prop", text="➕ 新規西洋窓を生成", icon='ADD')

            # 📖 Dictionary (Single Book) Specific
            elif props.prop_category == 'DICTIONARY':
                box_dict = layout.box()
                box_dict.label(text="📖 中性的辞書・大型書籍 (Dictionary / Book):", icon='BOOKMARKS')
                
                # 1. 表紙・装丁スタイル
                box_cover = box_dict.box()
                box_cover.label(text="装丁・表紙カラー:", icon='COLOR')
                box_cover.prop(props, "dictionary_color_preset", text="表紙色")
                box_cover.prop(props, "dictionary_rib_count", text="背リブ本数 (3~5本)")
                box_cover.prop(props, "dictionary_has_ribbon", text="布製しおり紐 (Ribbon Bookmark)")

                # 2. 背表紙アーチ & 小口凹み
                box_form = box_dict.box()
                box_form.label(text="製本プロポーション:", icon='MOD_SUBSURF')
                row_form = box_form.row(align=True)
                row_form.prop(props, "dictionary_spine_curvature", text="背の丸み", slider=True)
                row_form.prop(props, "dictionary_fore_edge_hollow", text="小口の窪み", slider=True)

                # 3. 紙の年季・黄ばみ (古書エイジング)
                box_age = box_dict.box()
                box_age.label(text="古書エイジング・紙の年季:", icon='BRUSH_DATA')
                box_age.prop(props, "dictionary_page_aging", text="紙の黄ばみ・経年感", slider=True)

                # 4. 謎文字・古代グリフ箔押し
                box_rune = box_dict.box()
                box_rune.label(text="謎文字・古代ルーン刻印:", icon='FORCE_VORTEX')
                box_rune.prop(props, "dictionary_has_runes", text="表紙・背表紙に謎文字を刻印")
                if props.dictionary_has_runes:
                    box_rune.prop(props, "dictionary_foil_style", text="箔押し様式")
                    box_rune.prop(props, "dictionary_rune_intensity", text="刻印の明瞭度・凹凸", slider=True)

            # 📚 Book Stack (Messy / Physics Pile) Specific
            elif props.prop_category == 'BOOK_STACK':
                box_stack = layout.box()
                box_stack.label(text="📚 本の山・積読・物理演算スタック (Book Stack):", icon='FILE_VOLUME')

                # 1. 冊数 & 積み様式
                box_stk_mode = box_stack.box()
                box_stk_mode.label(text="積み上げ設定 & 物理シミュレーション:", icon='MOD_BUILD')
                box_stk_mode.prop(props, "book_stack_count", text="本の冊数 (2~30冊)")
                box_stk_mode.prop(props, "book_stack_style", text="積み様式")
                if props.book_stack_style in ('MESSY', 'DESK_SCATTER', 'PHYSICS'):
                    box_stk_mode.prop(props, "book_stack_scatter_radius", text="散乱・ズレ半径 (m)", slider=True)
                    box_stk_mode.prop(props, "book_stack_drop_dynamics", text="転がり・乱雑落下度", slider=True)
                    box_stk_mode.prop(props, "book_stack_include_ground", text="🪵 地面（床板）をアセットに含める")

                # 2. スタイルバリエーション & 結合オプション
                box_stk_opt = box_stack.box()
                box_stk_opt.label(text="バリエーション & 最適化:", icon='PREFERENCES')
                box_stk_opt.prop(props, "book_stack_mix_styles", text="🎨 12色 ＆ 5大柄装飾（ルーン/格子/枠線/縞/無地）をバラバラにする")
                box_stk_opt.prop(props, "book_stack_combine", text="🎮 1つのStatic Meshに結合 (UE/Unity向け)")

                # 操作ボタン
                col_stk_btn = box_stack.column(align=True)
                col_stk_btn.scale_y = 1.3
                col_stk_btn.operator("mesh.reroll_selected_prop", text="🎲 本の山を再抽選・再積み上げ", icon='FILE_REFRESH')

            # 📄 Document Stack (Paper Pile) Specific
            elif props.prop_category == 'DOCUMENT_STACK':
                box_doc = layout.box()
                box_doc.label(text="📄 書類の束・紙の山 (Document / Paper Stack):", icon='DOCUMENTS')

                # 1. 層数 & 乱雑度
                box_doc_cfg = box_doc.box()
                box_doc_cfg.label(text="紙束・レイヤー設定:", icon='MOD_BUILD')
                box_doc_cfg.prop(props, "doc_layer_count", text="紙束の層数 (8~50層)")
                box_doc_cfg.prop(props, "doc_messiness", text="乱雑・飛び出し度", slider=True)
                box_doc_cfg.prop(props, "doc_include_folders", text="📑 クラフト紙・フォルダーを混ぜる")

                # 特徴ヒント
                box_doc_hint = box_doc.box()
                box_doc_hint.label(text="💡 白紙、クラフト紙、古紙、フォルダーが不揃いに重なるリアルな書類束", icon='INFO')
                box_doc_hint.label(text="   角の反り・めくれ＆ランダム飛び出しを幾何学的にめり込みゼロで生成")

                # 操作ボタン
                col_doc_btn = box_doc.column(align=True)
                col_doc_btn.scale_y = 1.3
                col_doc_btn.operator("mesh.reroll_selected_prop", text="🎲 書類の束を再抽選 (Re-Roll)", icon='FILE_REFRESH')

            # 🪨 Stone Stairs Specific (年季の入った石畳の地下階段)
            elif props.prop_category == 'STONE_STAIRS':
                box_stone = layout.box()
                box_stone.label(text="🪨 年季の入った石畳の地下階段 (Dungeon / Cellar Stairs):", icon='FILE_IMAGE')

                # 1. 階段・欄干スタイル & 配置
                box_st_style = box_stone.box()
                box_st_style.label(text="階段・欄干スタイル & 手すり配置:", icon='MOD_BUILD')
                box_st_style.prop(props, "stone_stairs_style", text="様式")
                box_st_style.prop(props, "stone_stairs_rail_placement", text="手すり配置")

                # 2. 階段寸法 & 段数
                box_st_dim = box_stone.box()
                box_st_dim.label(text="寸法 & 段数設定:", icon='EMPTY_DATA')
                row_dim1 = box_st_dim.row(align=True)
                row_dim1.prop(props, "stone_stairs_step_count", text="段数")
                row_dim1.prop(props, "stone_stairs_width", text="階段幅")

                row_dim2 = box_st_dim.row(align=True)
                row_dim2.prop(props, "stone_stairs_step_depth", text="踏み面奥行")
                row_dim2.prop(props, "stone_stairs_step_height", text="蹴上げ高")

                box_st_dim.prop(props, "stone_stairs_include_landing", text="🏢 最下段の踊り場・地下フロア延長")

                # 3. 年季の入った風化・エイジング表現
                box_st_aging = box_stone.box()
                box_st_aging.label(text="年季・風化エイジング表現:", icon='EXPERIMENTAL')
                box_st_aging.prop(props, "stone_stairs_wear_amount", text="中央すり減り摩耗")
                box_st_aging.prop(props, "stone_stairs_damage", text="角欠け・チッピング")
                box_st_aging.prop(props, "stone_stairs_moss", text="苔・湿気汚れ")

                # 4. マテリアル & エクスポート
                box_st_mat = box_stone.box()
                box_st_mat.label(text="マテリアル & 出力設定:", icon='MATERIAL')
                box_st_mat.prop(props, "stone_stairs_material", text="石材プリセット")
                box_st_mat.prop(props, "stone_stairs_combine", text="🎮 1つのStatic Meshに結合")

                # 特徴ヒント
                box_st_hint = box_stone.box()
                box_st_hint.label(text="💡 動画準拠の壺型バラスター＋親柱＆長年の歩行摩耗すり減り", icon='INFO')

                # 再生成ボタン
                col_st_btn = box_stone.column(align=True)
                col_st_btn.scale_y = 1.3
                col_st_btn.operator("mesh.update_selected_prop", text="🔄 パラメータを反映・更新 (選択中を更新)", icon='FILE_REFRESH')
                row_st_sub = col_st_btn.row(align=True)
                row_st_sub.operator("mesh.reroll_selected_prop", text="🎲 形状を再抽選 (Re-Roll)", icon='DICE')
                row_st_sub.operator("mesh.create_new_prop", text="➕ 新規石畳階段を生成", icon='ADD')

            # 🪜 Spiral Stairs Specific
            elif props.prop_category == 'SPIRAL_STAIRS':
                box_stairs = layout.box()
                box_stairs.label(text="🪜 手すり付き螺旋階段 (Spiral Stairs):", icon='FILE_IMAGE')

                # 1. 階段スタイル & 寸法構造
                box_s_geom = box_stairs.box()
                box_s_geom.label(text="螺旋構造 & 寸法設定:", icon='MOD_BUILD')
                box_s_geom.prop(props, "spiral_stairs_style", text="スタイル")
                
                row_steps = box_s_geom.row(align=True)
                row_steps.prop(props, "spiral_stairs_step_count", text="段数")
                row_steps.prop(props, "spiral_stairs_step_height", text="段高")

                row_rad = box_s_geom.row(align=True)
                row_rad.prop(props, "spiral_stairs_radius", text="外径半径")
                row_rad.prop(props, "spiral_stairs_inner_radius", text="支柱半径")

                box_s_geom.prop(props, "spiral_stairs_step_angle", text="1段の回転角(度)")

                # 2. 手すり & 手すり子（バラスター）
                box_s_rail = box_stairs.box()
                box_s_rail.label(text="螺旋手すり & バラスター:", icon='CON_FOLLOWPATH')
                box_s_rail.prop(props, "spiral_stairs_has_handrail", text="〰️ 連続螺旋手すり")
                if props.spiral_stairs_has_handrail:
                    box_s_rail.prop(props, "spiral_stairs_baluster_style", text="手すり子装飾")
                box_s_rail.prop(props, "spiral_stairs_has_pillar", text="🏛️ センター支柱")

                # 3. マテリアル設定
                box_s_mat = box_stairs.box()
                box_s_mat.label(text="マテリアル & エクスポート設定:", icon='MATERIAL')
                if props.spiral_stairs_style == 'CLASSIC_WOOD':
                    box_s_mat.prop(props, "spiral_stairs_tread_material", text="踏み板木目")
                    box_s_mat.prop(props, "spiral_stairs_metal_material", text="手すり金属")
                box_s_mat.prop(props, "spiral_stairs_combine", text="🎮 1つのStatic Meshに結合")

                # 特徴ヒント
                box_s_hint = box_stairs.box()
                box_s_hint.label(text="💡 ねじれのない滑らかな3D螺旋手すり＆扇形ノーズ重なり構造", icon='INFO')

                # 操作ボタン
                col_s_btn = box_stairs.column(align=True)
                col_s_btn.scale_y = 1.3
                col_s_btn.operator("mesh.update_selected_prop", text="🔄 パラメータを反映・更新 (選択中を更新)", icon='FILE_REFRESH')
                row_s_sub = col_s_btn.row(align=True)
                row_s_sub.operator("mesh.reroll_selected_prop", text="🎲 形状を再抽選 (Re-Roll)", icon='DICE')
                row_s_sub.operator("mesh.create_new_prop", text="➕ 新規螺旋階段を生成", icon='ADD')

            # 🌿 Houseplant Specific
            elif props.prop_category == 'HOUSEPLANT':
                box_plant = layout.box()
                box_plant.label(text="🌿 観葉植物・鉢植え (Houseplant / Potted Foliage):", icon='FILE_IMAGE')

                # 1. スタイル & ボリューム
                box_p_style = box_plant.box()
                box_p_style.label(text="観葉植物スタイル & 葉密度:", icon='MOD_BUILD')
                box_p_style.prop(props, "houseplant_style", text="様式")
                box_p_style.prop(props, "houseplant_leaf_shape", text="葉の形状パターン")
                box_p_style.prop(props, "houseplant_density", text="葉の繁茂・密度")

                # 2. 鉢 & 葉の素材
                box_p_mat = box_plant.box()
                box_p_mat.label(text="鉢 ＆ 葉のマテリアル質感:", icon='MATERIAL')
                box_p_mat.prop(props, "houseplant_pot_material", text="植木鉢素材")
                box_p_mat.prop(props, "houseplant_leaf_color", text="葉の基本色")
                box_p_mat.prop(props, "houseplant_variegated", text="✨ 斑入り葉 (Variegated)")
                box_p_mat.prop(props, "houseplant_combine", text="🎮 1つのStatic Meshに結合")

                # 特徴ヒント
                box_p_hint = box_plant.box()
                box_p_hint.label(text="💡 樋状V字カーブ立体葉 & 樹冠球状法線転送 (SSS半透明)", icon='INFO')

                # 操作ボタン
                col_p_btn = box_plant.column(align=True)
                col_p_btn.scale_y = 1.3
                col_p_btn.operator("mesh.reroll_selected_prop", text="🎲 観葉植物を再生成 (Re-Roll)", icon='FILE_REFRESH')

            # 🕯️ Candle Stand Specific
            elif props.prop_category == 'CANDLE_STAND':
                box_candle = layout.box()
                box_candle.label(text="🕯️ アンティーク蝋燭立て (Candle Stand / Chandelier):", icon='LIGHT_SUN')

                # 1. スタイル & 本数
                box_c_style = box_candle.box()
                box_c_style.label(text="燭台スタイル & 蝋燭本数:", icon='MOD_BUILD')
                box_c_style.prop(props, "candle_stand_style", text="様式")
                if props.candle_stand_style in ('HANGING_CHANDELIER', 'TABLE_CANDELABRA', 'WALL_SCONCE'):
                    box_c_style.prop(props, "candle_count", text="蝋燭本数")

                # 2. 蝋燭ディテール & 炎
                box_c_detail = box_candle.box()
                box_c_detail.label(text="蝋の溶け具合 & 炎・ライト:", icon='LIGHT_POINT')
                box_c_detail.prop(props, "candle_melt_level", text="蝋だれ・溶け度", slider=True)
                row_flame = box_c_detail.row(align=True)
                row_flame.prop(props, "candle_has_flame", text="🔥 炎メッシュ点灯", toggle=True)
                row_flame.prop(props, "candle_add_lights", text="💡 Point Light配置", toggle=True)

                # 3. PBRマテリアル設定
                box_c_mat = box_candle.box()
                box_c_mat.label(text="PBRマテリアル質感:", icon='MATERIAL')
                box_c_mat.prop(props, "candle_holder_material", text="金具素材")
                box_c_mat.prop(props, "candle_wax_material", text="蝋燭素材")
                box_c_mat.prop(props, "candle_combine", text="🎮 1つのStatic Meshに結合")

                # 操作ボタン
                col_c_btn = box_candle.column(align=True)
                col_c_btn.scale_y = 1.3
                col_c_btn.operator("mesh.reroll_selected_prop", text="🎲 蝋燭立てを再生成 (Re-Roll)", icon='FILE_REFRESH')

            # 🪟 Curtain (Drapes & Wind Sim) Specific
            elif props.prop_category == 'CURTAIN':
                box_curtain = layout.box()
                box_curtain.label(text="🪟 カーテン・ドレープ布地 (Curtain & Drapes):", icon='MOD_CLOTH')

                # 1. カーテン様式 & 布地
                box_c_style = box_curtain.box()
                box_c_style.label(text="プリーツ様式 & 布地マテリアル:", icon='MOD_SUBSURF')
                box_c_style.prop(props, "curtain_style", text="開き方")
                box_c_style.prop(props, "curtain_pleats", text="ヒダ数 (プリーツ)")
                box_c_style.prop(props, "curtain_smoothness", text="丸み・柔らかさ")
                box_c_style.prop(props, "curtain_fabric_type", text="布地素材")

                # 2. カーテンロッド・レール金具
                box_c_rod = box_curtain.box()
                box_c_rod.label(text="カーテンレール・金具 (Rod & Rings):", icon='SNAP_VOLUME')
                box_c_rod.prop(props, "curtain_include_rod", text="🪵 レール・リング金具を生成")
                if props.curtain_include_rod:
                    box_c_rod.prop(props, "curtain_rod_style", text="金具素材")

                # 3. 開閉・束ね設定 (Open/Close & Tie-back)
                box_c_open = box_curtain.box()
                box_c_open.label(text="開閉・束ね設定 (Open/Close & Tie-back):", icon='DRIVER_DISTANCE')
                box_c_open.prop(props, "curtain_open_amount", text="開閉度 (0:閉 ~ 1:全開)", slider=True)
                row_open_opts = box_c_open.row(align=True)
                row_open_opts.prop(props, "curtain_tied_back", text="🎗️ タッセルで束ねる", toggle=True)
                row_open_opts.prop(props, "curtain_generate_shapekey", text="🎮 UE5モーフターゲット出力", toggle=True)

                # 4. 横風シミュレーション & ベイク
                box_c_wind = box_curtain.box()
                box_c_wind.label(text="横風シミュレーション & UE5対応:", icon='FORCE_WIND')
                box_c_wind.prop(props, "curtain_simulate_wind", text="💨 Blender内横風Clothシミュレーション")
                if props.curtain_simulate_wind:
                    box_c_wind.prop(props, "curtain_wind_strength", text="風の強さ", slider=True)
                    box_c_wind.prop(props, "curtain_bake_static", text="📌 風で膨らんだ瞬間を静止メッシュ確定 (UE用)")
                box_c_wind.prop(props, "curtain_combine", text="🎮 1つのStatic Meshに結合 (UE/Unity向け)")

                # 特徴ヒント
                box_c_hint = box_curtain.box()
                box_c_hint.label(text="💡 UE5風揺れ対応: 頂点カラー(R:ピン, G:中央スリット, B:左右識別, A:ヒダ)自動ベイク済み", icon='INFO')
                box_c_hint.label(text="   中央の合わせ目から左右それぞれ異なる位相で風になびくシェーダー制御が可能")

                # 操作ボタン
                col_c_btn = box_curtain.column(align=True)
                col_c_btn.scale_y = 1.3
                col_c_btn.operator("mesh.reroll_selected_prop", text="🎲 カーテンを再生成・再送風", icon='FILE_REFRESH')

            # Dimensions Box
            box_dim = layout.box()
            row_dh = box_dim.row(align=True)
            row_dh.label(text="Dimensions (サイズ):", icon='EMPTY_DATA')
            row_dh.prop(props, "rand_dimensions", text="🎲 ランダム")
            
            row_d = box_dim.row(align=True)
            row_d.enabled = not props.rand_dimensions
            if (props.prop_category in ('FLOOR', 'GRASS')) and props.floor_shape in ('CIRCLE', 'HEXAGON'):
                row_d.prop(props, "size_x", text="直径")
                row_d.prop(props, "size_z", text="厚み/高さ")
            else:
                row_d.prop(props, "size_x", text="X (幅)")
                row_d.prop(props, "size_y", text="Y (奥行)")
                row_d.prop(props, "size_z", text="Z (高さ)")

            # Surface / Fractures for Rock & Architecture
            if props.prop_category in ("FLOOR", "WALL"):
                box_scar = layout.box()
                row_sch = box_scar.row(align=True)
                row_sch.label(text="Organic Cracks (有機的亀裂・傷):", icon='MOD_BOOLEAN')
                row_sch.prop(props, "rand_fractures", text="🎲 ランダム")
                col_sc = box_scar.column(align=True)
                col_sc.enabled = not props.rand_fractures
                col_sc.prop(props, "floor_crack_count", text="亀裂・傷の箇所数 (1~20)")
                col_sc.prop(props, "crack_depth", text="亀裂の深さ・太さ", slider=True)
            elif props.prop_category in ("ROCK", "CRAG"):
                box_rock = layout.box()
                box_rock.label(text="Rock Type & Palette (岩石タイプ＆色彩):", icon='COLORSET_03_VEC')
                row_rt = box_rock.row(align=True)
                row_rt.prop(props, "rock_type", text="")
                row_rt.prop(props, "rand_type", text="🎲 形状")
                box_rock.prop(props, "rock_palette", text="🎨 カラーパレット")

                box_surf = layout.box()
                row_sh = box_surf.row(align=True)
                row_sh.label(text="Surface (粗さ・削り):", icon='MOD_SUBSURF')
                row_sh.prop(props, "rand_surface", text="🎲 ランダム")
                col_s = box_surf.column(align=True)
                col_s.enabled = not props.rand_surface
                col_s.prop(props, "roughness", slider=True)
                col_s.prop(props, "chisel_strength", slider=True)

                box_frac = layout.box()
                row_fh = box_frac.row(align=True)
                row_fh.label(text="Fractures (欠け・亀裂):", icon='MOD_BOOLEAN')
                row_fh.prop(props, "rand_fractures", text="🎲 ランダム")
                col_f = box_frac.column(align=True)
                col_f.enabled = not props.rand_fractures
                col_f.prop(props, "big_chunk_cuts")
                col_f.prop(props, "crack_depth", slider=True)

        # 🌟 5. Tab 2: Textures & UV Mapping Mode
        elif props.studio_tab == 'TEX':
            box_map = layout.box()
            box_map.label(text="Texture UV Mapping Mode (貼り方):", icon='UV')
            box_map.prop(props, "uv_mapping_mode", text="")
            if props.uv_mapping_mode == 'TILING':
                box_map.prop(props, "texture_tiling", text="リピート倍率", slider=True)

            box_tex = layout.box()
            box_tex.label(text="PBR Texture Folder (自動連動):", icon='FILE_FOLDER')
            box_tex.prop(props, "texture_folder", text="")
            
            row_tf = box_tex.row(align=True)
            row_tf.prop(props, "use_folder_texture", text="テクスチャ有効")
            row_tf.prop(props, "rand_texture", text="🎲 ランダム")
            
            if props.use_folder_texture and not props.rand_texture:
                box_tex.prop(props, "selected_texture", text="")
            
            box_tex.operator("mesh.apply_random_texture_only", text="🎨 テクスチャのみ再抽選", icon='IMAGE_DATA')

            # 🏔️ 3D Displacement Box
            box_disp = layout.box()
            box_disp.label(text="🏔️ 3D ディスプレイスメント (凹凸立体化):", icon='MOD_DISPLACE')
            box_disp.prop(props, "enable_displacement", text="3D凹凸立体化を有効化")
            if props.enable_displacement:
                col_d = box_disp.column(align=True)
                col_d.prop(props, "displacement_strength", text="凹凸の強さ", slider=True)
                col_d.prop(props, "displacement_midlevel", text="基準高さ", slider=True)
                col_d.prop(props, "displacement_subdiv", text="メッシュ細分化 (0~4)")
                col_d.prop(props, "apply_disp_to_mesh", text="🎮 生成時に即時適用 (オフで微調整可能)")

        # 🌟 6. Tab 3: Export Settings
        elif props.studio_tab == 'EXPORT':
            # 🔥 Auto PBR Texture Baker Box
            box_bake = layout.box()
            box_bake.label(text="🔥 Auto PBR Baker (Unityベタ塗り解消):", icon='RENDER_STILL')
            box_bake.prop(props, "bake_resolution", text="解像度")
            row_bp = box_bake.row(align=True)
            row_bp.prop(props, "bake_diffuse", text="BaseColor (色)")
            row_bp.prop(props, "bake_normal", text="Normal (法線)")
            box_bake.prop(props, "auto_bake_on_export", text="⚡ FBX出力時に自動ベイクする")
            
            row_bact = box_bake.row(align=True)
            row_bact.scale_y = 1.3
            row_bact.operator("mesh.bake_prop_textures", text="🔥 手動で今すぐベイク", icon='TEXTURE')

            box_exp = layout.box()
            box_exp.label(text="Unity FBX Settings:", icon='EXPORT')
            box_exp.prop(props, "asset_name", text="アセット名")
            box_exp.prop(props, "export_folder", text="")
            row_exp_btns = box_exp.row(align=True)
            row_exp_btns.operator("mesh.open_export_folder", text="📂 保存先を開く", icon='FOLDER_REDIRECT')
            
            active_obj = context.active_object
            if active_obj and active_obj.type == 'MESH' and active_obj.modifiers:
                box_exp.operator("mesh.apply_all_modifiers", text=f"🔘 全モディファイアを一括適用 ({len(active_obj.modifiers)}個)", icon='CHECKMARK')
